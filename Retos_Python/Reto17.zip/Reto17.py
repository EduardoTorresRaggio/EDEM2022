tupla = (2, 4, 3, 5, 4, 6, 7, 8, 6, 1)

print("Los elementos de 3 a 5 son: {}".format(tupla[3:5]))
print("Los 6 primeros elementos son: "+str(tupla[:6]))
print("Los elementos 6 hasta el final son: "+ str(tupla[4:]))
print("La tupla es esta: " + str(tupla[:]))
print("Los elementos desde el 2 hasta el 9 de 2 en 2 " + str(tupla[1:9:2]))
print("Los numeros cada 4 saltos son: " + str(tupla[0:10:4]))
print("Los numeros desde la posicion 9 al 2 son " + str(tupla[9:1:-1]))


